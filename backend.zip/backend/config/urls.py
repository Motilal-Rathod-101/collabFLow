from django.contrib import admin
from django.urls import path, include
from .views import home

urlpatterns = [
     path('home/', home),
    path("admin/", admin.site.urls),
    path("api/", include("core.urls")),
    path("api/", include("workspaces.urls")),
    path("api/", include("projects.urls")),
    path("api/", include("tasks.urls")),
    path("api/", include("comments.urls")),
]
