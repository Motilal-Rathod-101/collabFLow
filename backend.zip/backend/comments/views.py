# from django.shortcuts import render

from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Comment
from .serializers import CommentSerializer
from rest_framework.permissions import AllowAny

class CommentListView(APIView):
    permission_classes = [AllowAny]
    
    def get(self, request):
        comments = Comment.objects.all()
        serializer = CommentSerializer(comments, many=True)
        return Response(serializer.data)
